nix::shim::main() (
    local EXIT_CODE

    # GitHub Action Secret bug; strip appended '='
    NIX_CODESPACE_SECRET_AZURE_PASSWORD="${NIX_CODESPACE_SECRET_AZURE_PASSWORD//=/}"

    local -xr NIX=$$
    local -xr NIX_EXIT_RELOAD=100
    local -xr NIX_EXIT_REMAIN=101
    local -xr NIX_EXIT_CHROOT_REINITIALIZE=102
    local -xr NIX_EXIT_CHROOT_REMOVE=103
    local -xr NIX_REPO_DIR="$(cd "$(dirname ${BASH_SOURCE})"; pwd)"
    local -xr NIX_DIR="${NIX_REPO_DIR}/nix"
    local -xr NIX_LOADER="${NIX_DIR}/loader.sh"
    local -xr NIX_DIR_NIX_USR="${NIX_DIR}/usr"
    local -xr NIX_DIR_NIX_SRC="${NIX_DIR}/src"
    local -xr NIX_GITHUB_USER_RECORDS="${NIX_DIR_NIX_USR}/github-user"
    local -xr NIX_IP_ALLOCATION_RECORDS="${NIX_DIR_NIX_USR}/ip-allocation"
    local -xr NIX_SECRET_DIR="${NIX_REPO_DIR}/.secret"
    local -xr NIX_SECRET_AZURE_PASSWORD="${NIX_SECRET_DIR}/azure.password"
    local -xr NIX_SECRET_GITHUB_PASSWORD="${NIX_SECRET_DIR}/github.password"
    local -xr NIX_SECRET_GITHUB_PAT="${NIX_SECRET_DIR}/github.pat"
    local -xr NIX_CHROOT="${HOME}/chroot"

    # load functions; source *.sh files
    . "${NIX_DIR}/env.sh"
    while read; do source "${REPLY}"; done \
        < <(find "${NIX_DIR_NIX_SRC}" -type f -name "*.sh")

    # load user alias
    local ALIAS="$(nix::shim::my_alias)"
    local GITHUB_ALIAS="$(nix::shim::my_github_alias)"
    if [[ ! "${ALIAS}" ]] || [[ ! "${GITHUB_ALIAS}" ]]; then
        nix::shim::user::prompt
        ALIAS="$(nix::shim::my_alias)"
        GITHUB_ALIAS="$(nix::shim::my_github_alias)"
    fi

    # copy NIX variables holding secrets into files
    nix::shim::secret::init

    # setup chroot
    nix::shim::chroot::initialize
    nix::shim::chroot::adduser "${ALIAS}"

    while true; do
        (
            nix::shim::mount
            trap nix::shim::umount EXIT 

            local CMD=(
                'sudo' 'chroot' "${NIX_CHROOT}" 'su' '--login' "${ALIAS}"
            )

            if (( $# > 0 )); then
                # automated
                "${CMD[@]}" < <(echo "$@")
                return $?
            fi

            # interactive
            "${CMD[@]}"
        )
        EXIT_CODE=$?

        if (( EXIT_CODE == NIX_EXIT_RELOAD )); then
            continue
        fi

        if (( EXIT_CODE == NIX_EXIT_CHROOT_REINITIALIZE )); then
            nix::shim::chroot::remove
            nix::shim::chroot::initialize
            nix::shim::chroot::adduser "${ALIAS}"
            continue
        fi

        if (( EXIT_CODE == NIX_EXIT_CHROOT_REMOVE )); then
            nix::shim::chroot::remove
            return
        fi

        if (( EXIT_CODE == NIX_EXIT_REMAIN )); then
            return
        fi

        break
    done

    exit "${EXIT_CODE}"
)

nix::shim::mount::list() {
    mount -l | grep chroot
}

nix::shim::mount::test() {
    nix::shim::mount::list >/dev/null 2>&1
}

nix::shim::mount() {
    sudo mkdir -p "${NIX_CHROOT}/workspaces/"
    sudo mount --bind "/workspaces/" "${NIX_CHROOT}/workspaces/"
    
    sudo mount --bind "/proc/" "${NIX_CHROOT}/proc/"
    sudo mount --bind "/dev/pts/" "${NIX_CHROOT}/dev/pts/"
}

nix::shim::umount() {
    if ! nix::shim::mount::test; then
        return
    fi
    
    sudo umount "${NIX_CHROOT}/proc/"
    sudo umount "${NIX_CHROOT}/dev/pts/"
    sudo umount "${NIX_CHROOT}/workspaces/"
}

nix::shim::chroot::initialize() {
    if [[ -d "${NIX_CHROOT}" ]]; then
        return
    fi

    # make a copy of the golden chroot
    nix::tty::log::begin 'nix: shim: chroot: cloning'
    sudo cp -pr "${NIX_CHROOT_UNPACKED}" "${NIX_CHROOT}"
    nix::tty::log::end

    # loopback networking chroot setup
    echo "127.0.0.1 $HOSTNAME" \
        | sudo tee -a "${NIX_CHROOT}/etc/hosts" \
        >/dev/null

    # enable en
    cat ${NIX_CHROOT}/etc/locale.gen \
        | sed 's/# en_US.UTF-8/en_US.UTF-8/g' \
        | sudo tee "${NIX_CHROOT}/tmp/locale.gen" \
        >/dev/null
    sudo cp "${NIX_CHROOT}/tmp/locale.gen" "${NIX_CHROOT}/etc/locale.gen"

    # export NIX variables into chroot
    declare -p \
        | grep NIX \
        | egrep '(-rx|-x)' \
        | sed 's/-rx/-r/g' \
        | sed 's/-x/-r/g' \
        | sudo tee "${NIX_CHROOT}/etc/profile.d/nix.sh" \
        >/dev/null

    # default bash_login sources the loader
    cat <<-EOF | sudo tee "${NIX_CHROOT}/etc/skel/.bash_login" > /dev/null
		. "\${HOME}/.profile"
		. "\${NIX_LOADER}"
		EOF

    nix::shim::chroot::prebuild
}

nix::shim::chroot::prebuild() (
    nix::shim::mount
    trap nix::shim::umount EXIT 

    (
        nix::tty::log::subproc::begin "nix: shim: prebuild: initializing locale"
        sudo chroot "${NIX_CHROOT}" locale-gen
    )
)


nix::shim::chroot::adduser() {
    local ALIAS="$1"

    if [[ -f "${NIX_CHROOT}/etc/sudoers.d/${ALIAS}" ]]; then
        return
    fi

    (
        # create user
        nix::tty::log::subproc::begin "nix: shim: user: adding ${ALIAS}"
        sudo chroot "${NIX_CHROOT}" adduser --disabled-password --gecos "" "${ALIAS}"
    )

    # password-less sudo
    echo "${ALIAS} ALL=(root) NOPASSWD:ALL" \
        | sudo tee "${NIX_CHROOT}/etc/sudoers.d/${ALIAS}" >/dev/null
    sudo chmod 0440 "${NIX_CHROOT}/etc/sudoers.d/${ALIAS}"

    # sudo userdel -R "${NIX_CHROOT}" -r chrkin >/dev/null 2>&1
    # sudo useradd --create-home -R "${NIX_CHROOT}" "${ALIAS}"
}

nix::shim::chroot::remove() {
    if [[ ! -d "${NIX_CHROOT}" ]]; then
        nix::tty::echo "nix: shim: chroot: not found at ${NIX_CHROOT}."
        return
    fi

    nix::shim::umount

    # double check to make sure nothing is mounted
    if nix::shim::mount::test; then
        nix::tty::echo "nix: shim: chroot: unable to remove because mounts remain."
        return
    fi

    nix::tty::log::begin 'nix: shim: chroot: removing'
    sudo rm -r -f "${NIX_CHROOT}"
    nix::tty::log::end
}

nix::shim::codespace::test() {
    [[ "${USER}" == 'codespace' ]] \
        || [[ "${USER}" == 'vscode' ]]
}

nix::shim::my_alias() {
    if nix::shim::codespace::test; then
        cat "${NIX_GITHUB_USER_RECORDS}" \
            | awk -v key="${GITHUB_USER}" '$1==key {print $2}'
        return
    fi

    echo "${USER}"
}

nix::shim::my_github_alias() {
    if nix::shim::codespace::test; then
        echo "${GITHUB_USER}"
        return
    fi

    cat "${NIX_GITHUB_USER_RECORDS}" \
        | awk -v key="${USER}" '$2==key {print $1}'
}

nix::shim::user::prompt() {
    local ALIAS="$(nix::shim::my_alias)"
    local GITHUB_ALIAS="$(nix::shim::my_github_alias)"

    nix::tty::echo "Welcome to the NIX shim! Please identify yourself."
    nix::tty::echo

    if [[ ! "${ALIAS}" ]]; then
        nix::tty::prompt 'Microsoft alias (e.g. "chrkin") > '
        ALIAS="${REPLY}"
    fi

    if [[ ! "${GITHUB_ALIAS}" ]]; then
        nix::tty::prompt 'Github alias (e.g. "kingces95") > '
        GITHUB_ALIAS="${REPLY}"
    fi

    nix::fs::insert "${NIX_GITHUB_USER_RECORDS}" "${GITHUB_ALIAS} ${ALIAS}"
    nix::tty::echo
}

nix::shim::secret::init() {
    # move secrets to files to reduce likelihood of logging them
    export -n NIX_CODESPACE_SECRET_AZURE_PASSWORD
    export -n NIX_CODESPACE_SECRET_AZURE_RELAY_SHARED_ACCESS_KEY
    
    export -n NIX_CODESPACE_SECRET_GITHUB_PASSWORD
    export -n NIX_CODESPACE_SECRET_GITHUB_PAT
    export -n NIX_CODESPACE_SECRET_GITHUB_MFA_CODE
    export -n NIX_CODESPACE_SECRET_GITHUB_PAT_REPO_SCOPE
    export -n NIX_CODESPACE_SECRET_GITHUB_RECOVERY_CODES

    nix::shim::secret::install \
        'azure password' \
        NIX_CODESPACE_SECRET_AZURE_PASSWORD \
        "${NIX_SECRET_AZURE_PASSWORD}"

    nix::shim::secret::install \
        'github password' \
        NIX_CODESPACE_SECRET_GITHUB_PASSWORD \
        "${NIX_SECRET_GITHUB_PASSWORD}"

    nix::shim::secret::install \
        'github personal access token' \
        NIX_CODESPACE_SECRET_GITHUB_PAT_REPO_SCOPE \
        "${NIX_SECRET_GITHUB_PAT}"
}

nix::shim::secret::install() {
    local NAME="$1"
    shift

    local VARIABLE="$1"
    shift

    local PTH="$1"
    shift

    if [[ ! -v "${VARIABLE}" ]]; then
        return
    fi

    if [[ -s "${PTH}" ]]; then
        return
    fi

    nix::tty::echo "nix: shim: codespace: installing ${NAME}"

    # save team secret
    sudo mkdir -p "$(dirname ${PTH})"
    echo "${!VARIABLE}" | sudo tee "${PTH}" >/dev/null
}

nix::shim::main "$@"
