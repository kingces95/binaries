GITHUB_USER=fidalgotesting

. "$(dirname ${BASH_SOURCE})/../shim.sh" nix::loader::prebuild
