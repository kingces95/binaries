readonly NIX_MY_DISPLAY_NAME="Fidalgo Testing"
readonly NIX_MY_TZ_OFFSET=-8h
readonly NIX_MY_IP_ALLOCATION="10.193.0.0/16"
readonly NIX_MY_ENV_ID=0
readonly NIX_MY_ENVIRONMENTS=(
    DOGFOOD_INT
    SELFHOST
    INT
    PPE
)
# readonly NIX_MY_DEFAULT_PROFILE=administrator
# readonly NIX_MY_DEFAULT_ENVIRONMENT=PPE

source "${NIX_DIR_NIX_USR}/alias.sh"
