alias api-code-install="nix::code::reinstall ${NIX_API_VSCODE_PLUGIN_VISUALIZER}"
alias api-open="code -r ${NIX_REPO_DIR_SRC}/sdk/specification/devtestcenter/resource-manager/Microsoft.Fidalgo/preview/${NIX_API_VERSION}/fidalgo.json"
