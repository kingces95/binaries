nix::assert() {
    echo "ASSERT FAILED: $@" >&2
}
