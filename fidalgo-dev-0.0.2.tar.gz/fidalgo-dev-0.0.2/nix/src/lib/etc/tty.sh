nix::tty::printf() {
    local FORMAT="$1"
    shift

    printf "$(nix::color::cyan "${FORMAT}")" "$@" >/dev/tty
}

nix::tty::error::printf() {
    local FORMAT="$1"
    shift

    printf "$(nix::color::red "${FORMAT}")" "$@" >/dev/tty
}

nix::tty::prompt() {
    printf "$(nix::color::begin::yellow)" >/dev/tty
    printf '%s' "$*" >/dev/tty
    printf "$(nix::color::end)" >/dev/tty
    read
}

nix::tty::color_reset() {
    echo -e -n "\033[0m" >/dev/tty
}

nix::tty::echo() {
    nix::tty::printf '%s\n' "$*"
}

nix::tty::log::begin() {
    nix::tty::printf '%s' "$* "
}

nix::tty::log::end() {
    nix::tty::echo "$@"
}

nix::tty::log::subproc::begin() {
    local LOG=$(mktemp "${NIX_OS_DIR_TEMP}/XXX.log")
    local ERR=$(mktemp "${NIX_OS_DIR_TEMP}/XXX.err")

    nix::tty::log::begin "$@ (logs: ${LOG} ${ERR})"
    exec 1>"${LOG}"
    exec 2>"${ERR}"

    trap nix::tty::log::subproc::end "${ERR}" EXIT 
}

nix::tty::log::subproc::end() {
    if [[ -s "${ERR}" ]]; then
        nix::tty::error::printf "!" 
    fi

    nix::tty::log::end
}
