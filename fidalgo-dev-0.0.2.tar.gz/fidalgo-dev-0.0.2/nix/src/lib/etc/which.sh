nix::which::test() {
    which "$1" >/dev/null
}
