alias clr-cmd="nix::dotnet::cmd"

nix::dotnet::cmd() {
    nix::cmd::name 'dotnet'
}