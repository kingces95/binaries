alias fd-secret-github-pat="nix::secret::github::pat::cat"
alias fd-secret-github-pat-path="nix::secret::github::pat::path"

nix::secret::github::pat::path() {
    echo "${NIX_SECRET_GITHUB_PAT}"
}

nix::secret::github::pat::cat() {
    cat "${NIX_SECRET_GITHUB_PAT}"
}
