alias fd-secret-azure-password="nix::secret::azure::password::cat"
alias fd-secret-azure-password-rm="nix::secret::azure::password::rm"
alias fd-secret-azure-password-path="nix::secret::azure::password::path"
alias fd-secret-azure-password-read="nix::secret::azure::password::read"
alias fd-secret-azure-password-set="nix::secret::azure::password::set"
alias fd-secret-azure-password-get="nix::secret::azure::password::get"
alias fd-secret-azure-password-test="nix::secret::azure::password::test"

nix::secret::azure::password::read() {
    nix::secret::read 'azure password'
}

nix::secret::azure::password::path() {
    echo "${NIX_SECRET_AZURE_PASSWORD}"
}

nix::secret::azure::password::cat() {
    if ! nix::secret::azure::password::test; then
        return
    fi

    cat "${NIX_SECRET_AZURE_PASSWORD}"
}

nix::secret::azure::password::test() {
    [[ -s "${NIX_SECRET_AZURE_PASSWORD}" ]]
}

nix::secret::azure::password::rm() {
    if ! nix::secret::azure::password::test; then
        return
    fi

    rm "${NIX_SECRET_AZURE_PASSWORD}"
}

nix::secret::azure::password::set() {
    local SECRET="$1"
    if ! nix::secret::azure::password::test \
        || [[ ! $"{SECRET}" == "$(nix::secret::azure::password::cat)" ]]; then
        echo "${SECRET}" > "${NIX_SECRET_AZURE_PASSWORD}"
    fi
}

nix::secret::azure::password::get() {
    if nix::secret::azure::password::test; then
        nix::secret::azure::password::cat
    else
        nix::secret::azure::password::read >&2
        nix::secret::azure::password::set "${REPLY}"
        nix::secret::azure::password::get
    fi
}
