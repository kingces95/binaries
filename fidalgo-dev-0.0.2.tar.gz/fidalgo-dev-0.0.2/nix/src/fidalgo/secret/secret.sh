nix::secret::prompt() {
    nix::tty::printf '%s' "$* > "
    read -s
    echo '********'
}

nix::secret::read() {
    local NAME="$1"
    shift

    while true; do
        nix::secret::prompt "Enter ${NAME} secret" >&2
        local SECRET="${REPLY}"

        nix::secret::prompt "Re-enter ${NAME} secret" >&2
        if [[ ! "${SECRET}" == "${REPLY}" ]]; then
            nix::tty::echo "Passwords do not match." >&2
            continue
        fi

        break
    done
}