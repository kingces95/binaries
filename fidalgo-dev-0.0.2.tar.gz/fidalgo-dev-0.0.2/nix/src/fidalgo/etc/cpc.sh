alias fd-cpc-open-bug="nix::shell::browser::open ${NIX_WWW_CPC_BUG_INTEGRATION}"
alias fd-cpc-open-feature="nix::shell::browser::open ${NIX_WWW_CPC_FEATURE}"
alias fd-cpc-open-dogfood-bug="nix::shell::browser::open ${NIX_WWW_CPC_BUG}"
