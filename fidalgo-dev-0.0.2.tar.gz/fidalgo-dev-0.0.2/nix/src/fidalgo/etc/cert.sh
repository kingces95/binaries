alias fd-cert="alias -p | grep cert"
alias fd-cert-www="nix::shell::browser::open ${NIX_CERT_WWW}"
alias fd-cert-icm="nix::shell::browser::open ${NIX_CERT_ICM}"
