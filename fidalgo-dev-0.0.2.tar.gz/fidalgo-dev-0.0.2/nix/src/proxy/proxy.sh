alias fd-proxy-start="nix::proxy::start"

nix::proxy::enable() {
    export HTTPS_PROXY=socks5h://127.0.0.1:2224
}

nix::proxy::disable() {
    unset HTTPS_PROXY
}

nix::proxy::start() {
    declare -g VPT_AZURE_RELAY_NAMESPACE='vpt-fidalgo-relay'

    local SOCKS_PORT=2224
    local RELAY_HOST=127.0.0.2
    local RELAY_PORT=2223
    local RELAY_CONNECTION_STRING=$(
        az relay namespace authorization-rule keys list \
            --resource-group 'vpt-fidalgo-rg' \
            --name 'RootManageSharedAccessKey' \
            --namespace-name 'vpt-fidalgo-relay' \
            --query primaryConnectionString \
            --output tsv
    )

    # running install in an async subproc allows nc install
    # to start before lock is released for azbridge install
    nix::tool::install azbridge

    azbridge \
        -L "${RELAY_HOST}:${RELAY_PORT}:bridge" \
        -x "${RELAY_CONNECTION_STRING}" &

    # sudo netstat -a | grep 2223
    nix::proxy::uup "${RELAY_HOST}" "${RELAY_PORT}"

    nix::proxy::key::install

    ssh \
        -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null \
        -o LogLevel=ERROR \
        -D "${SOCKS_PORT}" \
        -p "${RELAY_PORT}" \
        -N \
        "anon@${RELAY_HOST}" \
        &
}

nix::proxy::uup() {
    # https://www.golinuxcloud.com/test-ssh-connection/

    local HOST="$1"
    shift

    local PORT="$1"
    shift

    local TIMEOUT="${1-60}"
    shift

    nix::proxy::timeout "${TIMEOUT}" nc -z "${HOST}" "${PORT}"
}

nix::proxy::timeout() {
    local TIMEOUT="$1"
    shift

    local TICKS
    for (( TICKS=0; TICKS<"${TIMEOUT}"; TICKS++ )); do
        if "$@"; then
            return;
        fi
          
        sleep 1
    done

    echo "ERROR: Timeout waiting for port '$@'." 1>&2
    return 1
}


nix::proxy::key::install() {
    local SSH_PRIVATE_KEY="${NIX_DIR_NIX_SSH}/id_rsa"
    local USER_PRIVATE_KEY="${HOME}/.ssh/id_rsa"

    if [[ -f "{USER_PRIVATE_KEY}" ]]; then
        return
    fi

    # authenticate clients by private key
    install -m u=rw,go= "${SSH_PRIVATE_KEY}" "${USER_PRIVATE_KEY}"
}

nix::jobs::stop() {
    while kill -9 % >/dev/null 2>&1; do
        sleep 1
    done
}