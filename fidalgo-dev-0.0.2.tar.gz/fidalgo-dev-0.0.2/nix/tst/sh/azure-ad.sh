(
    fd-login-as-network-administrator
    az group create \
        --name ${NIX_CPC_RESOURCE_GROUP} \
        --subscription ${NIX_CPC_SUBSCRIPTION} \
        --location ${NIX_CPC_LOCATION}
    az network vnet create \
        --name ${NIX_ENV_PREFIX}-my-vnet \
        --resource-group ${NIX_CPC_RESOURCE_GROUP} \
        --subscription ${NIX_CPC_SUBSCRIPTION} \
        --location ${NIX_CPC_LOCATION}
    az network vnet subnet create \
        --name ${NIX_ENV_PREFIX}-my-subnet \
        --vnet-name ${NIX_ENV_PREFIX}-my-vnet \
        --resource-group ${NIX_CPC_RESOURCE_GROUP} \
        --subscription ${NIX_CPC_SUBSCRIPTION} \
        --address-prefixes 10.0.0.0/24 \
        --delegations Microsoft.Fidalgo/networkSettings
)
(
    fd-login-as-administrator
    az group create \
        --name ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION} \
        --location ${NIX_FID_LOCATION}
    az fidalgo admin dev-center create \
        --name ${NIX_ENV_PREFIX}-my-dev-center \
        --resource-group ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION} \
        --identity-type SystemAssigned \
        --location ${NIX_FID_LOCATION}
    az fidalgo admin dev-center show \
        --name ${NIX_ENV_PREFIX}-my-dev-center \
        --resource-group ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION}

    az fidalgo admin network-setting create \
        --name ${NIX_ENV_PREFIX}-my-azure-ad-network-setting \
        --resource-group ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION} \
        --domain-join-type AzureADJoin \
        --location ${NIX_FID_LOCATION} \
        --subnet-id /subscriptions/${NIX_CPC_SUBSCRIPTION}/resourceGroups/${NIX_CPC_RESOURCE_GROUP}/providers/Microsoft.Network/virtualNetworks/${NIX_ENV_PREFIX}-my-vnet/subnets/${NIX_ENV_PREFIX}-my-subnet
    az fidalgo admin network-setting show \
        --name ${NIX_ENV_PREFIX}-my-azure-ad-network-setting \
        --resource-group ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION}


    az fidalgo admin attached-network create \
        --name ${NIX_ENV_PREFIX}-my-azure-ad-attached-network \
        --dev-center-name ${NIX_ENV_PREFIX}-my-dev-center \
        --resource-group ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION} \
        --network-connection-resource-id /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/networksettings/${NIX_ENV_PREFIX}-my-azure-ad-network-setting
    az fidalgo admin devbox-definition create \
        --name ${NIX_ENV_PREFIX}-my-devbox-definition \
        --resource-group ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION} \
        --dev-center-name ${NIX_ENV_PREFIX}-my-dev-center \
        --image-reference \
            id=/subscriptions/${NIX_CPC_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/devcenters/${NIX_ENV_PREFIX}-my-dev-center/galleries/Default/images/MicrosoftWindowsDesktop_windows-ent-cpc_win11-21h2-ent-cpc-m365 \
        --location ${NIX_FID_LOCATION} \
        --sku-name PrivatePreview
    az fidalgo admin project create \
        --name ${NIX_ENV_PREFIX}-my-project \
        --resource-group ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION} \
        --dev-center-id /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/devcenters/${NIX_ENV_PREFIX}-my-dev-center \
        --location ${NIX_FID_LOCATION}
    az role assignment create \
        --assignee ${NIX_ENV_PERSONA_DEVELOPER} \
        --role "DevCenter Dev Box User" \
        --scope /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/projects/${NIX_ENV_PREFIX}-my-project \
        --subscription ${NIX_FID_SUBSCRIPTION}

    az fidalgo admin network-setting show-health-detail \
        --name ${NIX_ENV_PREFIX}-my-azure-ad-network-setting \
        --resource-group ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION}
    az fidalgo admin network-setting show \
        --name ${NIX_ENV_PREFIX}-my-azure-ad-network-setting \
        --resource-group ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION}

    # declare -x AZURE_CORE_OUTPUT="none"
    az fidalgo admin pool create \
        --name ${NIX_ENV_PREFIX}-my-pool \
        --project-name ${NIX_ENV_PREFIX}-my-project \
        --resource-group ${NIX_FID_RESOURCE_GROUP} \
        --subscription ${NIX_FID_SUBSCRIPTION} \
        --devbox-definition-name ${NIX_ENV_PREFIX}-my-devbox-definition \
        --location "${NIX_FID_LOCATION}" \
        --network-connection-name ${NIX_ENV_PREFIX}-my-azure-ad-attached-network
)
(
    fd-login-as-developer
    az fidalgo dev virtual-machine create \
        --name ${NIX_ENV_PREFIX}-my-vm \
        --project-name ${NIX_ENV_PREFIX}-my-project \
        --subscription ${NIX_FID_SUBSCRIPTION} \
        --dev-center ${NIX_ENV_PREFIX}-my-dev-center \
        --fidalgo-dns-suffix "${NIX_FID_DNS_SUFFIX}" \
        --pool-name ${NIX_ENV_PREFIX}-my-pool \
        --user-id $(fd-login-as-vm-user; az-signed-in-user-id)
    az resource delete \
        --ids /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/projects/${NIX_ENV_PREFIX}-my-project/virtualmachine/${NIX_ENV_PREFIX}-my-vm \
        --yes
)
(
    fd-login-as-administrator
    az resource delete \
        --ids /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/projects/${NIX_ENV_PREFIX}-my-project/pools/${NIX_ENV_PREFIX}-my-pool \
        --yes
    az resource delete \
        --ids /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/projects/${NIX_ENV_PREFIX}-my-project \
        --yes
    az resource delete \
        --ids /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/devboxdefinitions/${NIX_ENV_PREFIX}-my-devbox-definition \
        --yes
    az resource delete \
        --ids /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/devcenters/${NIX_ENV_PREFIX}-my-dev-center/attachednetworks/${NIX_ENV_PREFIX}-my-azure-ad-attached-network \
        --yes
    az resource delete \
        --ids /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/networksettings/${NIX_ENV_PREFIX}-my-azure-ad-network-setting \
        --yes
    az resource delete \
        --ids /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP}/providers/Microsoft.Fidalgo/devcenters/${NIX_ENV_PREFIX}-my-dev-center \
        --yes
    az resource delete \
        --ids /subscriptions/${NIX_FID_SUBSCRIPTION}/resourceGroups/${NIX_FID_RESOURCE_GROUP} \
        --yes
)
(
    fd-login-as-network-administrator
    az resource delete \
        --ids /subscriptions/${NIX_CPC_SUBSCRIPTION}/resourceGroups/${NIX_CPC_RESOURCE_GROUP}/providers/Microsoft.Network/virtualNetworks/${NIX_ENV_PREFIX}-my-vnet/subnets/${NIX_ENV_PREFIX}-my-subnet \
        --yes
    az resource delete \
        --ids /subscriptions/${NIX_CPC_SUBSCRIPTION}/resourceGroups/${NIX_CPC_RESOURCE_GROUP}/providers/Microsoft.Network/virtualNetworks/${NIX_ENV_PREFIX}-my-vnet \
        --yes
    az resource delete \
        --ids /subscriptions/${NIX_CPC_SUBSCRIPTION}/resourceGroups/${NIX_CPC_RESOURCE_GROUP} \
        --yes
)
